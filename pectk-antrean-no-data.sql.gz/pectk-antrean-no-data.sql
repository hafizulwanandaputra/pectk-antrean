-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 21 Jul 2025 pada 06.40
-- Versi server: 11.8.2-MariaDB
-- Versi PHP: 8.3.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pectk-antrean`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `antrean`
--

CREATE TABLE `antrean` (
  `id_antrean` bigint(24) UNSIGNED NOT NULL,
  `kode_antrean` char(1) NOT NULL,
  `nomor_antrean` varchar(3) NOT NULL,
  `tanggal_antrean` datetime NOT NULL DEFAULT current_timestamp(),
  `status` enum('BELUM DIPANGGIL','SUDAH DIPANGGIL','BATAL','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `jaminan`
--

CREATE TABLE `jaminan` (
  `jaminanId` bigint(20) UNSIGNED NOT NULL,
  `jaminanKode` char(4) NOT NULL,
  `jaminanAntrian` varchar(10) NOT NULL,
  `jaminanNama` varchar(255) NOT NULL,
  `jaminanStatus` enum('AKTIF','TIDAK') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `jaminan`
--

INSERT INTO `jaminan` VALUES
(1, 'UMUM', 'A', 'UMUM / PRIBADI', 'AKTIF'),
(2, 'BPJS', 'B', 'BPJS KESEHATAN', 'TIDAK'),
(3, 'ADME', 'C', 'ADMEDIKA', 'TIDAK'),
(4, 'INHL', 'D', 'MANDIRI INHEALTH', 'TIDAK'),
(5, 'PRUD', 'E', 'PRUDENTIAL', 'TIDAK'),
(6, 'ALLI', 'F', 'ALLIANZ', 'TIDAK'),
(7, 'MANU', 'G', 'MANULIFE', 'TIDAK'),
(8, 'SINA', 'H', 'SINARMAS', 'TIDAK'),
(9, 'AAIA', 'I', 'AIA', 'TIDAK'),
(10, 'AXAM', 'J', 'AXA MANDIRI', 'TIDAK'),
(11, 'FWDL', 'K', 'FWD LIFE', 'TIDAK'),
(12, 'BRIL', 'L', 'BRI LIFE', 'TIDAK'),
(13, 'ADIR', 'M', 'ADIRA', 'TIDAK'),
(14, 'ASTR', 'N', 'ASTRA LIFE', 'TIDAK'),
(15, 'BUMI', 'O', 'BUMIPUTERA', 'TIDAK'),
(16, 'JMPR', 'P', 'JAMINAN PERUSAHAAN', 'TIDAK'),
(17, 'JKSS', 'Q', 'JKSS', 'TIDAK'),
(18, 'ASRS', 'R', 'ASURANSI', 'TIDAK');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_user` bigint(20) UNSIGNED NOT NULL,
  `fullname` varchar(512) NOT NULL,
  `username` varchar(512) NOT NULL,
  `password` varchar(512) NOT NULL,
  `profilephoto` varchar(512) DEFAULT NULL,
  `role` varchar(128) NOT NULL,
  `kode_antrian` varchar(24) DEFAULT NULL,
  `auto_date` tinyint(1) DEFAULT NULL,
  `active` tinyint(1) NOT NULL,
  `registered` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_sessions`
--

CREATE TABLE `user_sessions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `id_user` bigint(20) UNSIGNED NOT NULL,
  `session_token` varchar(255) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `ip_address` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `antrean`
--
ALTER TABLE `antrean`
  ADD PRIMARY KEY (`id_antrean`);

--
-- Indeks untuk tabel `jaminan`
--
ALTER TABLE `jaminan`
  ADD PRIMARY KEY (`jaminanId`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- Indeks untuk tabel `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_sessions_id_user_foreign` (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `antrean`
--
ALTER TABLE `antrean`
  MODIFY `id_antrean` bigint(24) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `jaminan`
--
ALTER TABLE `jaminan`
  MODIFY `jaminanId` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id_user` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `user_sessions`
--
ALTER TABLE `user_sessions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD CONSTRAINT `user_sessions_id_user_foreign` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
